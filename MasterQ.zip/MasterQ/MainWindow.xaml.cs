using System;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
using MasterQ.Core;

namespace MasterQ
{
    public partial class MainWindow : Window
    {
        private GameManager gameManager;
        private GameMode selectedGameMode;
        private DispatcherTimer gameTimer;
        private int gameTime;
        private bool isDarkTheme = false;
        private Core.EffectSystem effectSystem;
        private Core.AudioSystem audioSystem;

        public MainWindow()
        {
            InitializeComponent();
            InitializeGame();
            InitializeTimer();
        }

        private void InitializeGame()
        {
            gameManager = new GameManager();
            gameManager.GameStarted += GameManager_GameStarted;
            gameManager.GameEnded += GameManager_GameEnded;
            gameManager.MoveMade += GameManager_MoveMade;
            gameManager.StatusChanged += GameManager_StatusChanged;

            goBoard.MoveMade += GoBoard_MoveMade;

            // 初始化特效系统
            effectSystem = new Core.EffectSystem(goBoard);

            // 初始化音频系统
            audioSystem = new Core.AudioSystem();

            selectedGameMode = GameMode.TwoPlayer;
        }

        private void InitializeTimer()
        {
            gameTimer = new DispatcherTimer();
            gameTimer.Interval = TimeSpan.FromSeconds(1);
            gameTimer.Tick += GameTimer_Tick;
            gameTime = 0;
        }

        private void GameTimer_Tick(object sender, EventArgs e)
        {
            gameTime++;
            TimeTextBlock.Text = $"时间: {gameTime / 60:00}:{gameTime % 60:00}";
        }

        private void GameManager_GameStarted(object sender, EventArgs e)
        {
            UpdateGameStatus();
            gameTime = 0;
            gameTimer.Start();
            
            // 触发游戏开始特效
            effectSystem.PlayGameStartEffect();
            
            // 播放游戏开始音效
            audioSystem.PlayGameStartSound();
        }

        private void GameManager_GameEnded(object sender, EventArgs e)
        {
            gameTimer.Stop();
            UpdateGameStatus();
            
            // 触发游戏结束特效
            if (gameManager.GetGoRules() != null)
            {
                var scores = gameManager.GetGoRules().CountTerritory();
                var winner = scores[0] > scores[1] ? Core.Player.Black : Core.Player.White;
                effectSystem.PlayGameEndEffect(winner);
            }
            else if (gameManager.GetGomokuRules() != null)
            {
                var winner = gameManager.GetGomokuRules().GetWinner();
                effectSystem.PlayGameEndEffect(winner);
            }
            
            // 播放游戏结束音效
            audioSystem.PlayGameEndSound();
        }

        private void GameManager_MoveMade(object sender, EventArgs e)
        {
            goBoard.UpdateBoard();
            UpdateGameStatus();
            UpdateMoveHistory();
            
            // 触发落子特效
            if (gameManager.GetGoRules() != null)
            {
                var lastMove = gameManager.GetGoRules().GetLastMove();
                if (lastMove != null)
                {
                    var currentPlayer = gameManager.GetGoRules().GetCurrentPlayer();
                    effectSystem.PlayPlacementEffect(lastMove.Value.X, lastMove.Value.Y, currentPlayer);
                }
            }
            else if (gameManager.GetGomokuRules() != null)
            {
                var lastMove = gameManager.GetGomokuRules().GetLastMove();
                if (lastMove != null)
                {
                    var currentPlayer = gameManager.GetGomokuRules().GetCurrentPlayer();
                    effectSystem.PlayPlacementEffect(lastMove.Value.X, lastMove.Value.Y, currentPlayer);
                }
            }
            
            // 播放落子音效
            audioSystem.PlayMoveSound();
        }

        private void GameManager_StatusChanged(object sender, string e)
        {
            StatusTextBlock.Text = e;
        }

        private void GoBoard_MoveMade(object sender, (int, int) e)
        {
            gameManager.MakeMove(e.Item1, e.Item2);
        }

        private void UpdateGameStatus()
        {
            if (gameManager.GetGoRules() != null)
            {
                var currentPlayer = gameManager.GetGoRules().GetCurrentPlayer();
                CurrentPlayerTextBlock.Text = currentPlayer == Player.Black ? "黑棋" : "白棋";

                var scores = gameManager.GetGoRules().CountTerritory();

            }
        }

        private void UpdateMoveHistory()
        {
            // 这里可以实现历史记录的更新
        }

        private void TitleBar_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                DragMove();
            }
        }

        private void MinimizeButton_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void MaximizeButton_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void FullscreenButton_Click(object sender, RoutedEventArgs e)
        {
            if (WindowState == WindowState.Normal)
            {
                WindowStyle = WindowStyle.None;
                WindowState = WindowState.Maximized;
            }
            else
            {
                WindowStyle = WindowStyle.SingleBorderWindow;
                WindowState = WindowState.Normal;
            }
        }

        private void ThemeButton_Click(object sender, RoutedEventArgs e)
        {
            isDarkTheme = !isDarkTheme;
            UpdateTheme(sender);
        }

        private void UpdateTheme(object sender)
        {
            if (isDarkTheme)
            {
                // 暗主题
                MainBorder.Background = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(30, 30, 30));
                TitleBorder.Background = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(40, 40, 40));
                
                // 更新所有元素的颜色
                foreach (var child in FindVisualChildren<System.Windows.Controls.Border>(this))
                {
                    if (child.Background is System.Windows.Media.SolidColorBrush && ((System.Windows.Media.SolidColorBrush)child.Background).Color == System.Windows.Media.Colors.White)
                    {
                        child.Background = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(50, 50, 50));
                    }
                }
                
                foreach (var child in FindVisualChildren<System.Windows.Controls.TextBlock>(this))
                {
                    if (child.Foreground is System.Windows.Media.SolidColorBrush && ((System.Windows.Media.SolidColorBrush)child.Foreground).Color == System.Windows.Media.Colors.Black)
                    {
                        child.Foreground = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Colors.White);
                    }
                }
                
                // 更新主题按钮图标
                if (sender is System.Windows.Controls.Button themeButton)
                {
                    if (themeButton.Content is System.Windows.Controls.TextBlock textBlock)
                    {
                        textBlock.Text = "☀️";
                    }
                }
            }
            else
            {
                // 亮主题
                MainBorder.Background = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(240, 240, 240));
                TitleBorder.Background = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(44, 62, 80));
                
                // 更新所有元素的颜色
                foreach (var child in FindVisualChildren<System.Windows.Controls.Border>(this))
                {
                    if (child.Background is System.Windows.Media.SolidColorBrush && ((System.Windows.Media.SolidColorBrush)child.Background).Color == System.Windows.Media.Color.FromRgb(50, 50, 50))
                    {
                        child.Background = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Colors.White);
                    }
                }
                
                foreach (var child in FindVisualChildren<System.Windows.Controls.TextBlock>(this))
                {
                    if (child.Foreground is System.Windows.Media.SolidColorBrush && ((System.Windows.Media.SolidColorBrush)child.Foreground).Color == System.Windows.Media.Colors.White)
                    {
                        // 只更新非标题栏的文本
                        if (!child.Text.Equals("MasterQ"))
                        {
                            child.Foreground = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Colors.Black);
                        }
                    }
                }
                
                // 更新主题按钮图标
                if (sender is System.Windows.Controls.Button themeButton)
                {
                    if (themeButton.Content is System.Windows.Controls.TextBlock textBlock)
                    {
                        textBlock.Text = "🌙";
                    }
                }
            }
        }

        private static System.Collections.Generic.IEnumerable<T> FindVisualChildren<T>(System.Windows.DependencyObject depObj) where T : System.Windows.DependencyObject
        {
            if (depObj != null)
            {
                for (int i = 0; i < System.Windows.Media.VisualTreeHelper.GetChildrenCount(depObj); i++)
                {
                    System.Windows.DependencyObject child = System.Windows.Media.VisualTreeHelper.GetChild(depObj, i);
                    if (child != null && child is T)
                    {
                        yield return (T)child;
                    }

                    foreach (T childOfChild in FindVisualChildren<T>(child))
                    {
                        yield return childOfChild;
                    }
                }
            }
        }

        private void TwoPlayerButton_Click(object sender, RoutedEventArgs e)
        {
            selectedGameMode = GameMode.TwoPlayer;
            StatusTextBlock.Text = "已选择双人对战模式";
        }

        private void StartGameButton_Click(object sender, RoutedEventArgs e)
        {
            // 播放按钮点击音效
            audioSystem.PlayButtonClickSound();
            
            // 获取选择的游戏模式
            var gameMode = GameModeComboBox.SelectedIndex == 1 ? "Gomoku" : "TwoPlayer";
            
            if (gameMode == "Gomoku")
            {
                gameManager.StartGame(GameMode.Gomoku);
                goBoard.SetGomokuRules(gameManager.GetGomokuRules());
                goBoard.UpdateBoard();
            }
            else
            {
                gameManager.StartGame(GameMode.TwoPlayer);
                goBoard.SetGoRules(gameManager.GetGoRules());
                goBoard.UpdateBoard();
            }
        }

        private void UndoButton_Click(object sender, RoutedEventArgs e)
        {
            // 播放按钮点击音效
            audioSystem.PlayButtonClickSound();
            
            gameManager.Undo();
            goBoard.UpdateBoard();
            UpdateGameStatus();
        }

        private void RedoButton_Click(object sender, RoutedEventArgs e)
        {
            // 播放按钮点击音效
            audioSystem.PlayButtonClickSound();
            
            gameManager.Redo();
            goBoard.UpdateBoard();
            UpdateGameStatus();
        }

        private void PauseButton_Click(object sender, RoutedEventArgs e)
        {
            // 播放按钮点击音效
            audioSystem.PlayButtonClickSound();
            
            if (gameManager.IsPaused())
            {
                gameManager.ResumeGame();
                // 恢复游戏计时
                gameTimer.Start();
            }
            else
            {
                gameManager.PauseGame();
                // 停止游戏计时
                gameTimer.Stop();
            }
        }

        private void SaveGameButton_Click(object sender, RoutedEventArgs e)
        {
            // 播放按钮点击音效
            audioSystem.PlayButtonClickSound();
            
            // 确保存档文件夹存在
            string saveFolder = GetSaveFolder();
            if (!System.IO.Directory.Exists(saveFolder))
            {
                System.IO.Directory.CreateDirectory(saveFolder);
            }

            var dialog = new Microsoft.Win32.SaveFileDialog
            {
                Filter = "MasterQ Game (*.mqg)|*.mqg|All files (*.*)|*.*",
                DefaultExt = ".mqg",
                Title = "保存游戏",
                InitialDirectory = saveFolder,
                FileName = $"Game_{System.DateTime.Now:yyyyMMdd_HHmmss}"
            };

            if (dialog.ShowDialog() == true)
            {
                gameManager.SaveGame(dialog.FileName);
                StatusTextBlock.Text = "游戏保存成功";
            }
        }

        private void LoadGameButton_Click(object sender, RoutedEventArgs e)
        {
            // 播放按钮点击音效
            audioSystem.PlayButtonClickSound();
            
            // 确保存档文件夹存在
            string saveFolder = GetSaveFolder();
            if (!System.IO.Directory.Exists(saveFolder))
            {
                System.IO.Directory.CreateDirectory(saveFolder);
            }

            var dialog = new Microsoft.Win32.OpenFileDialog
            {
                Filter = "MasterQ Game (*.mqg)|*.mqg|All files (*.*)|*.*",
                DefaultExt = ".mqg",
                Title = "加载游戏",
                InitialDirectory = saveFolder
            };

            if (dialog.ShowDialog() == true)
            {
                gameManager.LoadGame(dialog.FileName);
                goBoard.SetGoRules(gameManager.GetGoRules());
                goBoard.UpdateBoard();
                UpdateGameStatus();
            }
        }

        private void ImportSaveButton_Click(object sender, RoutedEventArgs e)
        {
            // 播放按钮点击音效
            audioSystem.PlayButtonClickSound();
            
            var dialog = new Microsoft.Win32.OpenFileDialog
            {
                Filter = "MasterQ Game (*.mqg)|*.mqg|All files (*.*)|*.*",
                DefaultExt = ".mqg",
                Title = "导入存档"
            };

            if (dialog.ShowDialog() == true)
            {
                // 确保存档文件夹存在
                string saveFolder = GetSaveFolder();
                if (!System.IO.Directory.Exists(saveFolder))
                {
                    System.IO.Directory.CreateDirectory(saveFolder);
                }

                // 复制文件到存档文件夹
                string fileName = System.IO.Path.GetFileName(dialog.FileName);
                string destinationPath = System.IO.Path.Combine(saveFolder, fileName);
                System.IO.File.Copy(dialog.FileName, destinationPath, true);

                StatusTextBlock.Text = "存档导入成功";
            }
        }

        private string GetSaveFolder()
        {
            string appData = System.Environment.GetFolderPath(System.Environment.SpecialFolder.ApplicationData);
            string saveFolder = System.IO.Path.Combine(appData, "MasterQ", "Saves");
            return saveFolder;
        }

        private void RecordGameButton_Click(object sender, RoutedEventArgs e)
        {
            // 播放按钮点击音效
            audioSystem.PlayButtonClickSound();
            
            // 确保存档文件夹存在
            string saveFolder = GetSaveFolder();
            if (!System.IO.Directory.Exists(saveFolder))
            {
                System.IO.Directory.CreateDirectory(saveFolder);
            }

            // 打开保存对话框
            var dialog = new Microsoft.Win32.SaveFileDialog
            {
                Filter = "MasterQ Game Record (*.mqg)|*.mqg|SGF File (*.sgf)|*.sgf|All files (*.*)|*.*",
                DefaultExt = ".mqg",
                Title = "保存棋谱",
                InitialDirectory = saveFolder,
                FileName = $"Record_{System.DateTime.Now:yyyyMMdd_HHmmss}"
            };

            if (dialog.ShowDialog() == true)
            {
                // 保存棋谱
                gameManager.SaveGame(dialog.FileName);
                
                // 更新状态文字
                StatusTextBlock.Text = "棋谱记录成功";
                
                // 显示成功提示弹窗
                System.Windows.MessageBox.Show("棋谱记录成功！", "操作成功", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Information);
                
                // 这里可以添加图标变化逻辑
            }
        }

        private void ReplayGameButton_Click(object sender, RoutedEventArgs e)
        {
            // 播放按钮点击音效
            audioSystem.PlayButtonClickSound();
            
            var dialog = new Microsoft.Win32.OpenFileDialog
            {
                Filter = "MasterQ Game Record (*.mqg)|*.mqg|SGF File (*.sgf)|*.sgf|All files (*.*)|*.*",
                DefaultExt = ".mqg",
                Title = "加载棋谱"
            };

            if (dialog.ShowDialog() == true)
            {
                StatusTextBlock.Text = "开始回放棋谱";
                // 这里可以实现棋谱回放功能
            }
        }

        private void AnalyzePositionButton_Click(object sender, RoutedEventArgs e)
        {
            // 播放按钮点击音效
            audioSystem.PlayButtonClickSound();
            
            var analyzer = new PositionAnalyzer(gameManager.GetGoRules());
            var result = analyzer.AnalyzePosition();

            StatusTextBlock.Text = $"黑棋领地: {result.TerritoryAnalysis.BlackTerritory}\n" +
                                     $"白棋领地: {result.TerritoryAnalysis.WhiteTerritory}\n" +
                                     $"中立领地: {result.TerritoryAnalysis.NeutralTerritory}\n" +
                                     $"攻击点: {result.AttackPoints.Count}\n" +
                                     $"防守点: {result.DefensePoints.Count}";

            // 高亮显示攻击点和防守点
            goBoard.HighlightPossibleMoves(result.AttackPoints);
        }

        private void VolumeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (audioSystem != null)
            {
                audioSystem.SetVolume((int)e.NewValue);
            }
        }
    }
}