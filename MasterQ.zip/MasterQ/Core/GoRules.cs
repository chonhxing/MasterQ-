using System;
using System.Collections.Generic;
using System.Linq;

namespace MasterQ.Core
{
    public enum Player
    {
        None,
        Black,
        White
    }

    public class GoRules
    {
        private const int BOARD_SIZE = 19;
        private Player[,] board;
        private Player currentPlayer;
        private int lastKoX = -1;
        private int lastKoY = -1;
        private List<Move> moveHistory;

        public GoRules()
        {
            InitializeBoard();
            currentPlayer = Player.Black;
            moveHistory = new List<Move>();
        }

        private void InitializeBoard()
        {
            board = new Player[BOARD_SIZE, BOARD_SIZE];
            for (int i = 0; i < BOARD_SIZE; i++)
            {
                for (int j = 0; j < BOARD_SIZE; j++)
                {
                    board[i, j] = Player.None;
                }
            }
        }

        public bool MakeMove(int x, int y)
        {
            // 检查位置是否有效
            if (!IsValidPosition(x, y))
                return false;

            // 检查位置是否为空
            if (board[x, y] != Player.None)
                return false;

            // 模拟落子
            board[x, y] = currentPlayer;

            // 检查是否有提子
            var capturedStones = CaptureStones(x, y);

            // 检查是否打劫
            if (capturedStones.Count == 1 && IsKo(x, y))
            {
                // 撤销落子
                board[x, y] = Player.None;
                return false;
            }

            // 检查是否自杀
            if (IsSuicide(x, y))
            {
                // 撤销落子
                board[x, y] = Player.None;
                return false;
            }

            // 记录打劫位置
            if (capturedStones.Count == 1)
            {
                lastKoX = capturedStones[0].X;
                lastKoY = capturedStones[0].Y;
            }
            else
            {
                lastKoX = -1;
                lastKoY = -1;
            }

            // 记录 move
            moveHistory.Add(new Move(x, y, currentPlayer, capturedStones));

            // 切换玩家
            currentPlayer = currentPlayer == Player.Black ? Player.White : Player.Black;

            return true;
        }

        private bool IsValidPosition(int x, int y)
        {
            return x >= 0 && x < BOARD_SIZE && y >= 0 && y < BOARD_SIZE;
        }

        private bool IsKo(int x, int y)
        {
            return x == lastKoX && y == lastKoY;
        }

        private bool IsSuicide(int x, int y)
        {
            // 检查新落子的棋子是否有气
            var group = GetGroup(x, y);
            return !HasLiberties(group);
        }

        private List<(int X, int Y)> CaptureStones(int x, int y)
        {
            var capturedStones = new List<(int X, int Y)>();

            // 检查四个方向的对方棋子
            var directions = new[] { (-1, 0), (1, 0), (0, -1), (0, 1) };
            foreach (var (dx, dy) in directions)
            {
                int nx = x + dx;
                int ny = y + dy;

                if (IsValidPosition(nx, ny) && board[nx, ny] != Player.None && board[nx, ny] != currentPlayer)
                {
                    var group = GetGroup(nx, ny);
                    if (!HasLiberties(group))
                    {
                        // 提子
                        foreach (var (gx, gy) in group)
                        {
                            board[gx, gy] = Player.None;
                            capturedStones.Add((gx, gy));
                        }
                    }
                }
            }

            return capturedStones;
        }

        private List<(int X, int Y)> GetGroup(int x, int y)
        {
            var group = new List<(int X, int Y)>();
            var visited = new bool[BOARD_SIZE, BOARD_SIZE];
            var player = board[x, y];

            if (player == Player.None)
                return group;

            var queue = new Queue<(int X, int Y)>();
            queue.Enqueue((x, y));
            visited[x, y] = true;

            while (queue.Count > 0)
            {
                var (cx, cy) = queue.Dequeue();
                group.Add((cx, cy));

                var directions = new[] { (-1, 0), (1, 0), (0, -1), (0, 1) };
                foreach (var (dx, dy) in directions)
                {
                    int nx = cx + dx;
                    int ny = cy + dy;

                    if (IsValidPosition(nx, ny) && !visited[nx, ny] && board[nx, ny] == player)
                    {
                        visited[nx, ny] = true;
                        queue.Enqueue((nx, ny));
                    }
                }
            }

            return group;
        }

        private bool HasLiberties(List<(int X, int Y)> group)
        {
            var visited = new bool[BOARD_SIZE, BOARD_SIZE];

            foreach (var (x, y) in group)
            {
                var directions = new[] { (-1, 0), (1, 0), (0, -1), (0, 1) };
                foreach (var (dx, dy) in directions)
                {
                    int nx = x + dx;
                    int ny = y + dy;

                    if (IsValidPosition(nx, ny) && !visited[nx, ny])
                    {
                        if (board[nx, ny] == Player.None)
                            return true;
                        visited[nx, ny] = true;
                    }
                }
            }

            return false;
        }

        public Player[,] GetBoard()
        {
            var copy = new Player[BOARD_SIZE, BOARD_SIZE];
            Array.Copy(board, copy, board.Length);
            return copy;
        }

        public Player GetCurrentPlayer()
        {
            return currentPlayer;
        }

        public bool Undo()
        {
            if (moveHistory.Count == 0)
                return false;

            var lastMove = moveHistory.Last();
            moveHistory.RemoveAt(moveHistory.Count - 1);

            // 撤销落子
            board[lastMove.X, lastMove.Y] = Player.None;

            // 恢复被提的棋子
            foreach (var (x, y) in lastMove.CapturedStones)
            {
                board[x, y] = lastMove.Player == Player.Black ? Player.White : Player.Black;
            }

            // 恢复玩家
            currentPlayer = lastMove.Player;

            // 恢复打劫状态
            if (lastMove.CapturedStones.Count == 1)
            {
                lastKoX = lastMove.X;
                lastKoY = lastMove.Y;
            }
            else
            {
                lastKoX = -1;
                lastKoY = -1;
            }

            return true;
        }

        public int[] CountTerritory()
        {
            // 简化的数子算法
            var territory = new int[3]; // 0: 空, 1: 黑, 2: 白
            var visited = new bool[BOARD_SIZE, BOARD_SIZE];

            for (int i = 0; i < BOARD_SIZE; i++)
            {
                for (int j = 0; j < BOARD_SIZE; j++)
                {
                    if (!visited[i, j] && board[i, j] == Player.None)
                    {
                        var group = GetEmptyGroup(i, j, visited);
                        var owner = DetermineTerritoryOwner(group);
                        territory[(int)owner] += group.Count;
                    }
                }
            }

            // 计算实际得分（黑棋贴7.5目）
            int blackScore = territory[1] + moveHistory.Count(m => m.Player == Player.Black);
            int whiteScore = territory[2] + moveHistory.Count(m => m.Player == Player.White) + 8; // 简化处理，贴8目

            return new[] { blackScore, whiteScore };
        }

        public (int X, int Y)? GetLastMove()
        {
            if (moveHistory.Count == 0)
                return null;
            
            var lastMove = moveHistory.Last();
            return (lastMove.X, lastMove.Y);
        }

        public Player GetBoardState(int x, int y)
        {
            if (x < 0 || x >= BOARD_SIZE || y < 0 || y >= BOARD_SIZE)
                return Player.None;
            
            return board[x, y];
        }

        public List<Move> GetMoveHistory()
        {
            return moveHistory;
        }

        private List<(int X, int Y)> GetEmptyGroup(int x, int y, bool[,] visited)
        {
            var group = new List<(int X, int Y)>();
            var queue = new Queue<(int X, int Y)>();

            queue.Enqueue((x, y));
            visited[x, y] = true;

            while (queue.Count > 0)
            {
                var (cx, cy) = queue.Dequeue();
                group.Add((cx, cy));

                var directions = new[] { (-1, 0), (1, 0), (0, -1), (0, 1) };
                foreach (var (dx, dy) in directions)
                {
                    int nx = cx + dx;
                    int ny = cy + dy;

                    if (IsValidPosition(nx, ny) && !visited[nx, ny] && board[nx, ny] == Player.None)
                    {
                        visited[nx, ny] = true;
                        queue.Enqueue((nx, ny));
                    }
                }
            }

            return group;
        }

        private Player DetermineTerritoryOwner(List<(int X, int Y)> group)
        {
            bool hasBlack = false;
            bool hasWhite = false;

            foreach (var (x, y) in group)
            {
                var directions = new[] { (-1, 0), (1, 0), (0, -1), (0, 1) };
                foreach (var (dx, dy) in directions)
                {
                    int nx = x + dx;
                    int ny = y + dy;

                    if (IsValidPosition(nx, ny))
                    {
                        if (board[nx, ny] == Player.Black)
                            hasBlack = true;
                        else if (board[nx, ny] == Player.White)
                            hasWhite = true;
                    }
                }
            }

            if (hasBlack && !hasWhite)
                return Player.Black;
            if (!hasBlack && hasWhite)
                return Player.White;
            return Player.None;
        }

        public class Move
        {
            public int X { get; }
            public int Y { get; }
            public Player Player { get; }
            public List<(int X, int Y)> CapturedStones { get; }

            public Move(int x, int y, Player player, List<(int X, int Y)> capturedStones)
            {
                X = x;
                Y = y;
                Player = player;
                CapturedStones = capturedStones;
            }
        }
    }
}