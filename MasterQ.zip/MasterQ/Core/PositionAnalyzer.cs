using System;
using System.Collections.Generic;
using System.Linq;
using MasterQ.Core;

namespace MasterQ.Core
{
    public class PositionAnalyzer
    {
        private GoRules goRules;

        public PositionAnalyzer(GoRules rules)
        {
            goRules = rules;
        }

        public AnalysisResult AnalyzePosition()
        {
            var board = goRules.GetBoard();
            var result = new AnalysisResult();

            // 分析领地
            result.TerritoryAnalysis = AnalyzeTerritory(board);

            // 分析棋子强弱
            result.StrengthAnalysis = AnalyzeStrength(board);

            // 分析潜在的攻击点
            result.AttackPoints = FindAttackPoints(board);

            // 分析潜在的防守点
            result.DefensePoints = FindDefensePoints(board);

            // 计算当前得分
            result.CurrentScore = goRules.CountTerritory();

            return result;
        }

        private TerritoryAnalysis AnalyzeTerritory(Player[,] board)
        {
            var analysis = new TerritoryAnalysis();
            var visited = new bool[19, 19];

            for (int i = 0; i < 19; i++)
            {
                for (int j = 0; j < 19; j++)
                {
                    if (!visited[i, j] && board[i, j] == Player.None)
                    {
                        var territory = GetTerritoryGroup(i, j, board, visited);
                        var owner = DetermineTerritoryOwner(territory, board);

                        if (owner == Player.Black)
                        {
                            analysis.BlackTerritory += territory.Count;
                            analysis.BlackTerritoryPoints.AddRange(territory);
                        }
                        else if (owner == Player.White)
                        {
                            analysis.WhiteTerritory += territory.Count;
                            analysis.WhiteTerritoryPoints.AddRange(territory);
                        }
                        else
                        {
                            analysis.NeutralTerritory += territory.Count;
                            analysis.NeutralTerritoryPoints.AddRange(territory);
                        }
                    }
                }
            }

            return analysis;
        }

        private List<(int, int)> GetTerritoryGroup(int x, int y, Player[,] board, bool[,] visited)
        {
            var group = new List<(int, int)>();
            var queue = new Queue<(int, int)>();

            queue.Enqueue((x, y));
            visited[x, y] = true;

            while (queue.Count > 0)
            {
                var (cx, cy) = queue.Dequeue();
                group.Add((cx, cy));

                var directions = new[] { (-1, 0), (1, 0), (0, -1), (0, 1) };
                foreach (var (dx, dy) in directions)
                {
                    int nx = cx + dx;
                    int ny = cy + dy;

                    if (nx >= 0 && nx < 19 && ny >= 0 && ny < 19 && !visited[nx, ny] && board[nx, ny] == Player.None)
                    {
                        visited[nx, ny] = true;
                        queue.Enqueue((nx, ny));
                    }
                }
            }

            return group;
        }

        private Player DetermineTerritoryOwner(List<(int, int)> territory, Player[,] board)
        {
            bool hasBlack = false;
            bool hasWhite = false;

            foreach (var (x, y) in territory)
            {
                var directions = new[] { (-1, 0), (1, 0), (0, -1), (0, 1) };
                foreach (var (dx, dy) in directions)
                {
                    int nx = x + dx;
                    int ny = y + dy;

                    if (nx >= 0 && nx < 19 && ny >= 0 && ny < 19)
                    {
                        if (board[nx, ny] == Player.Black)
                            hasBlack = true;
                        else if (board[nx, ny] == Player.White)
                            hasWhite = true;
                    }
                }
            }

            if (hasBlack && !hasWhite)
                return Player.Black;
            if (!hasBlack && hasWhite)
                return Player.White;
            return Player.None;
        }

        private StrengthAnalysis AnalyzeStrength(Player[,] board)
        {
            var analysis = new StrengthAnalysis();
            var visited = new bool[19, 19];

            for (int i = 0; i < 19; i++)
            {
                for (int j = 0; j < 19; j++)
                {
                    if (!visited[i, j] && board[i, j] != Player.None)
                    {
                        var group = GetStoneGroup(i, j, board, visited);
                        var strength = CalculateGroupStrength(group, board);

                        if (board[i, j] == Player.Black)
                        {
                            analysis.BlackGroups.Add(new GroupInfo { Group = group, Strength = strength });
                        }
                        else
                        {
                            analysis.WhiteGroups.Add(new GroupInfo { Group = group, Strength = strength });
                        }
                    }
                }
            }

            return analysis;
        }

        private List<(int, int)> GetStoneGroup(int x, int y, Player[,] board, bool[,] visited)
        {
            var group = new List<(int, int)>();
            var queue = new Queue<(int, int)>();
            var player = board[x, y];

            queue.Enqueue((x, y));
            visited[x, y] = true;

            while (queue.Count > 0)
            {
                var (cx, cy) = queue.Dequeue();
                group.Add((cx, cy));

                var directions = new[] { (-1, 0), (1, 0), (0, -1), (0, 1) };
                foreach (var (dx, dy) in directions)
                {
                    int nx = cx + dx;
                    int ny = cy + dy;

                    if (nx >= 0 && nx < 19 && ny >= 0 && ny < 19 && !visited[nx, ny] && board[nx, ny] == player)
                    {
                        visited[nx, ny] = true;
                        queue.Enqueue((nx, ny));
                    }
                }
            }

            return group;
        }

        private int CalculateGroupStrength(List<(int, int)> group, Player[,] board)
        {
            // 计算气数
            int liberties = CountLiberties(group, board);

            // 计算集团大小
            int size = group.Count;

            // 简单的强度计算
            if (liberties >= 4)
                return 3; // 强
            else if (liberties >= 2)
                return 2; // 中
            else
                return 1; // 弱
        }

        private int CountLiberties(List<(int, int)> group, Player[,] board)
        {
            int count = 0;
            var checkedPoints = new HashSet<(int, int)>();

            foreach (var (x, y) in group)
            {
                var directions = new[] { (-1, 0), (1, 0), (0, -1), (0, 1) };
                foreach (var (dx, dy) in directions)
                {
                    int nx = x + dx;
                    int ny = y + dy;

                    if (nx >= 0 && nx < 19 && ny >= 0 && ny < 19 && !checkedPoints.Contains((nx, ny)) && board[nx, ny] == Player.None)
                    {
                        count++;
                        checkedPoints.Add((nx, ny));
                    }
                }
            }

            return count;
        }

        private List<(int, int)> FindAttackPoints(Player[,] board)
        {
            var attackPoints = new List<(int, int)>();
            var visited = new bool[19, 19];

            for (int i = 0; i < 19; i++)
            {
                for (int j = 0; j < 19; j++)
                {
                    if (board[i, j] == Player.None)
                    {
                        // 检查是否是攻击点
                        if (IsAttackPoint(i, j, board))
                        {
                            attackPoints.Add((i, j));
                        }
                    }
                }
            }

            return attackPoints;
        }

        private bool IsAttackPoint(int x, int y, Player[,] board)
        {
            // 检查周围是否有弱的对方棋子
            var directions = new[] { (-1, 0), (1, 0), (0, -1), (0, 1) };
            foreach (var (dx, dy) in directions)
            {
                int nx = x + dx;
                int ny = y + dy;

                if (nx >= 0 && nx < 19 && ny >= 0 && ny < 19 && board[nx, ny] != Player.None && board[nx, ny] != goRules.GetCurrentPlayer())
                {
                    var group = GetStoneGroup(nx, ny, board, new bool[19, 19]);
                    int strength = CalculateGroupStrength(group, board);
                    if (strength <= 2)
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        private List<(int, int)> FindDefensePoints(Player[,] board)
        {
            var defensePoints = new List<(int, int)>();

            for (int i = 0; i < 19; i++)
            {
                for (int j = 0; j < 19; j++)
                {
                    if (board[i, j] == Player.None)
                    {
                        // 检查是否是防守点
                        if (IsDefensePoint(i, j, board))
                        {
                            defensePoints.Add((i, j));
                        }
                    }
                }
            }

            return defensePoints;
        }

        private bool IsDefensePoint(int x, int y, Player[,] board)
        {
            // 检查周围是否有弱的己方棋子
            var directions = new[] { (-1, 0), (1, 0), (0, -1), (0, 1) };
            foreach (var (dx, dy) in directions)
            {
                int nx = x + dx;
                int ny = y + dy;

                if (nx >= 0 && nx < 19 && ny >= 0 && ny < 19 && board[nx, ny] == goRules.GetCurrentPlayer())
                {
                    var group = GetStoneGroup(nx, ny, board, new bool[19, 19]);
                    int strength = CalculateGroupStrength(group, board);
                    if (strength <= 2)
                    {
                        return true;
                    }
                }
            }

            return false;
        }
    }

    public class AnalysisResult
    {
        public TerritoryAnalysis TerritoryAnalysis { get; set; }
        public StrengthAnalysis StrengthAnalysis { get; set; }
        public List<(int, int)> AttackPoints { get; set; }
        public List<(int, int)> DefensePoints { get; set; }
        public int[] CurrentScore { get; set; }

        public AnalysisResult()
        {
            AttackPoints = new List<(int, int)>();
            DefensePoints = new List<(int, int)>();
        }
    }

    public class TerritoryAnalysis
    {
        public int BlackTerritory { get; set; }
        public int WhiteTerritory { get; set; }
        public int NeutralTerritory { get; set; }
        public List<(int, int)> BlackTerritoryPoints { get; set; }
        public List<(int, int)> WhiteTerritoryPoints { get; set; }
        public List<(int, int)> NeutralTerritoryPoints { get; set; }

        public TerritoryAnalysis()
        {
            BlackTerritoryPoints = new List<(int, int)>();
            WhiteTerritoryPoints = new List<(int, int)>();
            NeutralTerritoryPoints = new List<(int, int)>();
        }
    }

    public class StrengthAnalysis
    {
        public List<GroupInfo> BlackGroups { get; set; }
        public List<GroupInfo> WhiteGroups { get; set; }

        public StrengthAnalysis()
        {
            BlackGroups = new List<GroupInfo>();
            WhiteGroups = new List<GroupInfo>();
        }
    }

    public class GroupInfo
    {
        public List<(int, int)> Group { get; set; }
        public int Strength { get; set; } // 1-弱, 2-中, 3-强
    }
}