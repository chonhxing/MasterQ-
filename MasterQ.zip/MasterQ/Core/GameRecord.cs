using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;
using MasterQ.Core;
using MasterQ.UI;

namespace MasterQ.Core
{
    [Serializable]
    public class GameRecord
    {
        public string GameName { get; set; }
        public string BlackPlayer { get; set; }
        public string WhitePlayer { get; set; }
        public DateTime GameDate { get; set; }
        public List<MoveRecord> Moves { get; set; }
        public int[] FinalScore { get; set; }

        public GameRecord()
        {
            Moves = new List<MoveRecord>();
            GameDate = DateTime.Now;
        }

        public void AddMove(int x, int y, Player player, List<(int, int)> capturedStones)
        {
            var move = new MoveRecord
            {
                MoveNumber = Moves.Count + 1,
                X = x,
                Y = y,
                Player = player,
                CapturedStones = capturedStones
            };
            Moves.Add(move);
        }

        public void Save(string filePath)
        {
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(GameRecord));
                using (StreamWriter writer = new StreamWriter(filePath))
                {
                    serializer.Serialize(writer, this);
                }
            }
            catch (Exception ex)
            {
                throw new Exception("保存棋谱失败: " + ex.Message);
            }
        }

        public static GameRecord Load(string filePath)
        {
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(GameRecord));
                using (StreamReader reader = new StreamReader(filePath))
                {
                    return (GameRecord)serializer.Deserialize(reader);
                }
            }
            catch (Exception ex)
            {
                throw new Exception("加载棋谱失败: " + ex.Message);
            }
        }

        public void Replay(GoBoardControl board, Action<int> onMoveCompleted)
        {
            // 清空棋盘
            var tempRules = new GoRules();
            board.SetGoRules(tempRules);
            board.UpdateBoard();

            // 逐个回放棋子
            for (int i = 0; i < Moves.Count; i++)
            {
                var move = Moves[i];
                tempRules.MakeMove(move.X, move.Y);
                board.UpdateBoard();
                onMoveCompleted?.Invoke(i + 1);
                // 可以添加延迟以观察回放效果
                System.Threading.Thread.Sleep(500);
            }
        }

        public string ToSGF()
        {
            // 转换为SGF格式
            string sgf = $"(;GM[1]FF[4]CA[UTF-8]AP[MasterQ]DT[{GameDate.ToString("yyyy-MM-dd")}]";
            sgf += $"PB[{BlackPlayer}]PW[{WhitePlayer}]";
            sgf += "SZ[19]";

            foreach (var move in Moves)
            {
                char color = move.Player == Player.Black ? 'B' : 'W';
                string coordinate = ConvertToSGFCoordinate(move.X, move.Y);
                sgf += $";{color}[{coordinate}]";
            }

            if (FinalScore != null)
            {
                sgf += $";RE[{(FinalScore[0] > FinalScore[1] ? "B+" : "W+")}{Math.Abs(FinalScore[0] - FinalScore[1])}]";
            }

            sgf += ")";
            return sgf;
        }

        private string ConvertToSGFCoordinate(int x, int y)
        {
            // SGF坐标转换
            char col = (char)('a' + x);
            char row = (char)('a' + (18 - y)); // SGF是从上到下计数
            return $"{col}{row}";
        }
    }

    [Serializable]
    public class MoveRecord
    {
        public int MoveNumber { get; set; }
        public int X { get; set; }
        public int Y { get; set; }
        public Player Player { get; set; }
        public List<(int, int)> CapturedStones { get; set; }

        public MoveRecord()
        {
            CapturedStones = new List<(int, int)>();
        }
    }
}