using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using MasterQ.Core;

namespace MasterQ.Core
{
    public enum GameMode
    {
        TwoPlayer,
        Gomoku
    }

    public enum AIDifficulty
    {
        Easy,
        Medium,
        Hard
    }

    public class GameManager
    {
        private GoRules goRules;
        private GomokuRules gomokuRules;
        private GameMode gameMode;
        private bool isPlayerTurn;
        private bool isPaused;
        private string playerName;
        private string opponentName;

        public event EventHandler GameStarted;
        public event EventHandler GameEnded;
        public event EventHandler MoveMade;
        public event EventHandler<string> StatusChanged;

        public GameManager()
        {
            goRules = new GoRules();
        }

        public void StartGame(GameMode mode, AIDifficulty difficulty = AIDifficulty.Medium, string playerName = "Player", string opponentName = "Opponent")
        {
            gameMode = mode;
            this.playerName = playerName;
            this.opponentName = opponentName;

            if (mode == GameMode.Gomoku)
            {
                gomokuRules = new GomokuRules();
            }
            else
            {
                goRules = new GoRules();
            }
            isPlayerTurn = true;

            GameStarted?.Invoke(this, EventArgs.Empty);
            StatusChanged?.Invoke(this, "游戏开始");
        }

        public bool MakeMove(int x, int y)
        {
            if (!isPlayerTurn || isPaused) return false;

            bool success = false;
            if (gameMode == GameMode.Gomoku)
            {
                success = gomokuRules.MakeMove(x, y);
            }
            else
            {
                success = goRules.MakeMove(x, y);
            }
            
            if (success)
            {
                MoveMade?.Invoke(this, EventArgs.Empty);
                StatusChanged?.Invoke(this, $"{playerName} 落子: ({x}, {y})");

                // 检查游戏是否结束
                if (CheckGameEnd())
                {
                    EndGame();
                    return true;
                }

                // 切换到对手回合
                isPlayerTurn = false;
                StatusChanged?.Invoke(this, $"{opponentName} 的回合");
                
                // 为了测试方便，这里添加一个延时，让玩家可以看到对手回合的状态
                // 实际应用中，这里应该有更复杂的逻辑来处理双人轮流落子
                if (!isPaused)
                {
                    System.Threading.Thread.Sleep(500);
                    
                    // 切换回玩家回合
                    isPlayerTurn = true;
                    StatusChanged?.Invoke(this, $"{playerName} 的回合");
                }
            }

            return success;
        }



        public bool Undo()
        {
            bool success = false;
            if (gameMode == GameMode.Gomoku)
            {
                success = gomokuRules.Undo();
            }
            else
            {
                success = goRules.Undo();
            }
            
            if (success)
            {
                MoveMade?.Invoke(this, EventArgs.Empty);
                StatusChanged?.Invoke(this, "悔棋成功");

                isPlayerTurn = true;
                StatusChanged?.Invoke(this, $"{playerName} 的回合");
            }
            return success;
        }

        public bool Redo()
        {
            // 这里可以实现重做功能
            return false;
        }

        public void SaveGame(string filePath)
        {
            try
            {
                // 保存游戏状态到文件
                // 这里使用简单的文本格式保存，实际应用中可以使用更复杂的格式如JSON或二进制
                using (System.IO.StreamWriter writer = new System.IO.StreamWriter(filePath))
                {
                    // 保存游戏模式
                    writer.WriteLine($"GameMode:{gameMode}");
                    
                    // 保存玩家信息
                    writer.WriteLine($"PlayerName:{playerName}");
                    writer.WriteLine($"OpponentName:{opponentName}");
                    
                    // 保存游戏状态
                    writer.WriteLine($"IsPlayerTurn:{isPlayerTurn}");
                    
                    // 保存棋盘状态
                    writer.WriteLine("Board:");
                    for (int i = 0; i < 19; i++)
                    {
                        for (int j = 0; j < 19; j++)
                        {
                            var player = goRules.GetBoardState(i, j);
                            writer.Write((int)player + " ");
                        }
                        writer.WriteLine();
                    }
                    
                    // 保存落子历史
                    writer.WriteLine("MoveHistory:");
                    var moveHistory = goRules.GetMoveHistory();
                    foreach (var move in moveHistory)
                    {
                        writer.WriteLine($"{move.X},{move.Y},{(int)move.Player}");
                    }
                }
                
                StatusChanged?.Invoke(this, "游戏已保存");
            }
            catch (System.Exception ex)
            {
                StatusChanged?.Invoke(this, $"保存游戏失败: {ex.Message}");
            }
        }

        public void LoadGame(string filePath)
        {
            try
            {
                // 从文件加载游戏状态
                using (System.IO.StreamReader reader = new System.IO.StreamReader(filePath))
                {
                    // 读取游戏模式
                    string line = reader.ReadLine();
                    if (line != null && line.StartsWith("GameMode:"))
                    {
                        string modeStr = line.Substring(9);
                        System.Enum.TryParse<GameMode>(modeStr, out gameMode);
                    }
                    
                    // 读取玩家信息
                    line = reader.ReadLine();
                    if (line != null && line.StartsWith("PlayerName:"))
                    {
                        playerName = line.Substring(11);
                    }
                    
                    line = reader.ReadLine();
                    if (line != null && line.StartsWith("OpponentName:"))
                    {
                        opponentName = line.Substring(13);
                    }
                    
                    // 读取游戏状态
                    line = reader.ReadLine();
                    if (line != null && line.StartsWith("IsPlayerTurn:"))
                    {
                        string turnStr = line.Substring(13);
                        bool.TryParse(turnStr, out isPlayerTurn);
                    }
                    
                    // 读取棋盘状态
                    line = reader.ReadLine();
                    if (line != null && line == "Board:")
                    {
                        goRules = new GoRules();
                        for (int i = 0; i < 19; i++)
                        {
                            line = reader.ReadLine();
                            if (line != null)
                            {
                                string[] cells = line.Split(' ');
                                for (int j = 0; j < 19 && j < cells.Length; j++)
                                {
                                    if (int.TryParse(cells[j], out int playerInt))
                                    {
                                        Player player = (Player)playerInt;
                                        if (player != Player.None)
                                        {
                                            goRules.MakeMove(i, j);
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    // 读取落子历史
                    line = reader.ReadLine();
                    if (line != null && line == "MoveHistory:")
                    {
                        // 这里可以根据需要加载落子历史
                    }
                }
                
                StatusChanged?.Invoke(this, "游戏已加载");
                MoveMade?.Invoke(this, EventArgs.Empty);
            }
            catch (System.Exception ex)
            {
                StatusChanged?.Invoke(this, $"加载游戏失败: {ex.Message}");
            }
        }

        private bool CheckGameEnd()
        {
            if (gameMode == GameMode.Gomoku)
            {
                return gomokuRules.IsGameOver();
            }
            else
            {
                // 围棋的游戏结束判断逻辑
                // 例如：双方连续虚手、达到最大手数等
                return false;
            }
        }

        private void EndGame()
        {
            if (gameMode == GameMode.Gomoku)
            {
                var winner = gomokuRules.GetWinner();
                string winnerColor = winner == Player.Black ? "黑棋" : "白棋";
                StatusChanged?.Invoke(this, $"游戏结束！{winnerColor} 获胜！");
            }
            else
            {
                var scores = goRules.CountTerritory();
                string winnerColor = scores[0] > scores[1] ? "黑棋" : "白棋";
                StatusChanged?.Invoke(this, $"游戏结束！{winnerColor} 获胜！\n黑棋: {scores[0]} 目, 白棋: {scores[1]} 目");
            }
            GameEnded?.Invoke(this, EventArgs.Empty);
        }

        public GoRules GetGoRules()
        {
            return goRules;
        }

        public GomokuRules GetGomokuRules()
        {
            return gomokuRules;
        }

        public GameMode GetGameMode()
        {
            return gameMode;
        }

        public bool IsPlayerTurn()
        {
            return isPlayerTurn;
        }

        public string GetCurrentPlayerName()
        {
            return isPlayerTurn ? playerName : opponentName;
        }

        public void PauseGame()
        {
            isPaused = true;
            StatusChanged?.Invoke(this, "游戏已暂停");
        }

        public void ResumeGame()
        {
            isPaused = false;
            StatusChanged?.Invoke(this, "游戏已恢复");
        }

        public bool IsPaused()
        {
            return isPaused;
        }
    }
}