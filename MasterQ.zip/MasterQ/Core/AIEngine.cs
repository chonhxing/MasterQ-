using System;
using System.Collections.Generic;
using System.Linq;
using MasterQ.Core;

namespace MasterQ.Core
{
    public class AIEngine
    {
        private AIDifficulty difficulty;
        private GoRules goRules;
        private Random random;

        public AIEngine(AIDifficulty difficulty, GoRules goRules)
        {
            this.difficulty = difficulty;
            this.goRules = goRules;
            this.random = new Random();
        }

        public (int X, int Y)? GetNextMove()
        {
            switch (difficulty)
            {
                case AIDifficulty.Easy:
                    return GetEasyMove();
                case AIDifficulty.Medium:
                    return GetMediumMove();
                case AIDifficulty.Hard:
                    return GetHardMove();
                default:
                    return GetEasyMove();
            }
        }

        private (int X, int Y)? GetEasyMove()
        {
            // 简单AI：随机选择一个合法位置
            var legalMoves = GetLegalMoves();
            if (legalMoves.Count == 0)
                return null;

            // 优先选择星位
            var starPoints = new List<(int, int)> { (3, 3), (3, 9), (3, 15), (9, 3), (9, 9), (9, 15), (15, 3), (15, 9), (15, 15) };
            var starMoves = legalMoves.Where(m => starPoints.Contains(m)).ToList();
            if (starMoves.Count > 0)
            {
                return starMoves[random.Next(starMoves.Count)];
            }

            // 否则随机选择
            return legalMoves[random.Next(legalMoves.Count)];
        }

        private (int X, int Y)? GetMediumMove()
        {
            // 中等AI：考虑简单的策略
            var legalMoves = GetLegalMoves();
            if (legalMoves.Count == 0)
                return null;

            // 1. 检查是否有可以提子的位置
            var captureMoves = new List<(int, int)>();
            foreach (var move in legalMoves)
            {
                // 模拟落子
                var tempBoard = goRules.GetBoard();
                bool success = goRules.MakeMove(move.Item1, move.Item2);
                if (success)
                {
                    // 检查是否有提子
                    var newBoard = goRules.GetBoard();
                    int capturedCount = 0;
                    for (int i = 0; i < 19; i++)
                    {
                        for (int j = 0; j < 19; j++)
                        {
                            if (tempBoard[i, j] != Player.None && newBoard[i, j] == Player.None)
                            {
                                capturedCount++;
                            }
                        }
                    }
                    if (capturedCount > 0)
                    {
                        captureMoves.Add(move);
                    }
                    // 撤销落子
                    goRules.Undo();
                }
            }

            if (captureMoves.Count > 0)
            {
                return captureMoves[random.Next(captureMoves.Count)];
            }

            // 2. 优先选择星位和边缘位置
            var goodMoves = legalMoves.Where(m => 
                (m.Item1 == 3 || m.Item1 == 9 || m.Item1 == 15 || m.Item1 == 0 || m.Item1 == 18) &&
                (m.Item2 == 3 || m.Item2 == 9 || m.Item2 == 15 || m.Item2 == 0 || m.Item2 == 18)
            ).ToList();

            if (goodMoves.Count > 0)
            {
                return goodMoves[random.Next(goodMoves.Count)];
            }

            // 3. 随机选择
            return legalMoves[random.Next(legalMoves.Count)];
        }

        private (int X, int Y)? GetHardMove()
        {
            // 困难AI：考虑更多策略
            var legalMoves = GetLegalMoves();
            if (legalMoves.Count == 0)
                return null;

            // 1. 检查是否有可以提子的位置
            var captureMoves = new List<(int, int)>();
            foreach (var move in legalMoves)
            {
                // 模拟落子
                var tempBoard = goRules.GetBoard();
                bool success = goRules.MakeMove(move.Item1, move.Item2);
                if (success)
                {
                    // 检查是否有提子
                    var newBoard = goRules.GetBoard();
                    int capturedCount = 0;
                    for (int i = 0; i < 19; i++)
                    {
                        for (int j = 0; j < 19; j++)
                        {
                            if (tempBoard[i, j] != Player.None && newBoard[i, j] == Player.None)
                            {
                                capturedCount++;
                            }
                        }
                    }
                    if (capturedCount > 0)
                    {
                        captureMoves.Add(move);
                    }
                    // 撤销落子
                    goRules.Undo();
                }
            }

            if (captureMoves.Count > 0)
            {
                return captureMoves[random.Next(captureMoves.Count)];
            }

            // 2. 检查是否需要防守
            var defenseMoves = new List<(int, int)>();
            foreach (var move in legalMoves)
            {
                // 模拟对手落子
                var tempBoard = goRules.GetBoard();
                // 切换到对手视角
                bool success = goRules.MakeMove(move.Item1, move.Item2);
                if (success)
                {
                    // 检查对手是否能提子
                    var newBoard = goRules.GetBoard();
                    int capturedCount = 0;
                    for (int i = 0; i < 19; i++)
                    {
                        for (int j = 0; j < 19; j++)
                        {
                            if (tempBoard[i, j] != Player.None && newBoard[i, j] == Player.None)
                            {
                                capturedCount++;
                            }
                        }
                    }
                    if (capturedCount > 0)
                    {
                        defenseMoves.Add(move);
                    }
                    // 撤销落子
                    goRules.Undo();
                }
            }

            if (defenseMoves.Count > 0)
            {
                return defenseMoves[random.Next(defenseMoves.Count)];
            }

            // 3. 优先选择星位和关键点
            var keyPoints = new List<(int, int)> {
                (3, 3), (3, 9), (3, 15),
                (9, 3), (9, 9), (9, 15),
                (15, 3), (15, 9), (15, 15),
                (6, 6), (6, 12), (12, 6), (12, 12)
            };

            var keyMoves = legalMoves.Where(m => keyPoints.Contains(m)).ToList();
            if (keyMoves.Count > 0)
            {
                return keyMoves[random.Next(keyMoves.Count)];
            }

            // 4. 选择中心区域
            var centerMoves = legalMoves.Where(m => 
                m.Item1 >= 6 && m.Item1 <= 12 && m.Item2 >= 6 && m.Item2 <= 12
            ).ToList();

            if (centerMoves.Count > 0)
            {
                return centerMoves[random.Next(centerMoves.Count)];
            }

            // 5. 随机选择
            return legalMoves[random.Next(legalMoves.Count)];
        }

        private List<(int, int)> GetLegalMoves()
        {
            var legalMoves = new List<(int, int)>();
            var board = goRules.GetBoard();

            for (int i = 0; i < 19; i++)
            {
                for (int j = 0; j < 19; j++)
                {
                    if (board[i, j] == Player.None)
                    {
                        // 模拟落子检查是否合法
                        bool success = goRules.MakeMove(i, j);
                        if (success)
                        {
                            legalMoves.Add((i, j));
                            // 撤销落子
                            goRules.Undo();
                        }
                    }
                }
            }

            return legalMoves;
        }
    }
}