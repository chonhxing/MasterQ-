using System;
using System.Collections.Generic;
using System.Linq;

namespace MasterQ.Core
{
    public class GomokuRules
    {
        private const int BOARD_SIZE = 15;
        private Player[,] board;
        private Player currentPlayer;
        private List<Move> moveHistory;

        public GomokuRules()
        {
            InitializeBoard();
            currentPlayer = Player.Black;
            moveHistory = new List<Move>();
        }

        private void InitializeBoard()
        {
            board = new Player[BOARD_SIZE, BOARD_SIZE];
            for (int i = 0; i < BOARD_SIZE; i++)
            {
                for (int j = 0; j < BOARD_SIZE; j++)
                {
                    board[i, j] = Player.None;
                }
            }
        }

        public bool MakeMove(int x, int y)
        {
            // 检查位置是否有效
            if (!IsValidPosition(x, y))
                return false;

            // 检查位置是否为空
            if (board[x, y] != Player.None)
                return false;

            // 落子
            board[x, y] = currentPlayer;

            // 记录 move
            moveHistory.Add(new Move(x, y, currentPlayer, new List<(int X, int Y)>()));

            // 检查是否获胜
            if (CheckWin(x, y))
            {
                return true;
            }

            // 切换玩家
            currentPlayer = currentPlayer == Player.Black ? Player.White : Player.Black;

            return true;
        }

        private bool IsValidPosition(int x, int y)
        {
            return x >= 0 && x < BOARD_SIZE && y >= 0 && y < BOARD_SIZE;
        }

        private bool CheckWin(int x, int y)
        {
            Player player = board[x, y];
            if (player == Player.None)
                return false;

            // 检查水平方向
            int count = 1;
            // 向左检查
            for (int i = x - 1; i >= 0 && board[i, y] == player; i--)
                count++;
            // 向右检查
            for (int i = x + 1; i < BOARD_SIZE && board[i, y] == player; i++)
                count++;
            if (count >= 5)
                return true;

            // 检查垂直方向
            count = 1;
            // 向上检查
            for (int j = y - 1; j >= 0 && board[x, j] == player; j--)
                count++;
            // 向下检查
            for (int j = y + 1; j < BOARD_SIZE && board[x, j] == player; j++)
                count++;
            if (count >= 5)
                return true;

            // 检查对角线方向（左上到右下）
            count = 1;
            // 左上检查
            for (int i = x - 1, j = y - 1; i >= 0 && j >= 0 && board[i, j] == player; i--, j--)
                count++;
            // 右下检查
            for (int i = x + 1, j = y + 1; i < BOARD_SIZE && j < BOARD_SIZE && board[i, j] == player; i++, j++)
                count++;
            if (count >= 5)
                return true;

            // 检查对角线方向（右上到左下）
            count = 1;
            // 右上检查
            for (int i = x + 1, j = y - 1; i < BOARD_SIZE && j >= 0 && board[i, j] == player; i++, j--)
                count++;
            // 左下检查
            for (int i = x - 1, j = y + 1; i >= 0 && j < BOARD_SIZE && board[i, j] == player; i--, j++)
                count++;
            if (count >= 5)
                return true;

            return false;
        }

        public Player[,] GetBoard()
        {
            var copy = new Player[BOARD_SIZE, BOARD_SIZE];
            Array.Copy(board, copy, board.Length);
            return copy;
        }

        public Player GetCurrentPlayer()
        {
            return currentPlayer;
        }

        public bool Undo()
        {
            if (moveHistory.Count == 0)
                return false;

            var lastMove = moveHistory.Last();
            moveHistory.RemoveAt(moveHistory.Count - 1);

            // 撤销落子
            board[lastMove.X, lastMove.Y] = Player.None;

            // 恢复玩家
            currentPlayer = lastMove.Player;

            return true;
        }

        public (int X, int Y)? GetLastMove()
        {
            if (moveHistory.Count == 0)
                return null;
            
            var lastMove = moveHistory.Last();
            return (lastMove.X, lastMove.Y);
        }

        public Player GetBoardState(int x, int y)
        {
            if (x < 0 || x >= BOARD_SIZE || y < 0 || y >= BOARD_SIZE)
                return Player.None;
            
            return board[x, y];
        }

        public List<Move> GetMoveHistory()
        {
            return moveHistory;
        }

        public bool IsGameOver()
        {
            if (moveHistory.Count == 0)
                return false;

            var lastMove = moveHistory.Last();
            return CheckWin(lastMove.X, lastMove.Y);
        }

        public Player GetWinner()
        {
            if (!IsGameOver())
                return Player.None;

            var lastMove = moveHistory.Last();
            return lastMove.Player;
        }

        public class Move
        {
            public int X { get; }
            public int Y { get; }
            public Player Player { get; }
            public List<(int X, int Y)> CapturedStones { get; }

            public Move(int x, int y, Player player, List<(int X, int Y)> capturedStones)
            {
                X = x;
                Y = y;
                Player = player;
                CapturedStones = capturedStones;
            }
        }
    }
}