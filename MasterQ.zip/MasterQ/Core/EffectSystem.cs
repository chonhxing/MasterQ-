using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Threading;
using MasterQ.UI;

namespace MasterQ.Core
{
    public class EffectSystem
    {
        private GoBoardControl boardControl;
        private Canvas effectCanvas;

        public EffectSystem(GoBoardControl board)
        {
            boardControl = board;
            // 获取棋盘的特效画布
            var fieldInfo = typeof(GoBoardControl).GetField("effectCanvas", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
            if (fieldInfo != null)
            {
                effectCanvas = (Canvas)fieldInfo.GetValue(boardControl);
            }
        }

        private int consecutiveMoves = 0;
        private (int, int) lastMovePosition = (-1, -1);

        public void PlayPlacementEffect(int x, int y, Player player)
        {
            if (effectCanvas == null) return;

            // 检查是否是连击
            if (IsConsecutiveMove(x, y))
            {
                consecutiveMoves++;
                if (consecutiveMoves >= 3)
                {
                    PlayComboEffect(x, y, player, consecutiveMoves);
                }
            }
            else
            {
                consecutiveMoves = 1;
            }
            lastMovePosition = (x, y);

            // 基础落子光晕效果
            PlayBasicPlacementEffect(x, y, player);

            // 特殊招式效果（根据位置和局面可能触发）
            if (IsSpecialMove(x, y))
            {
                PlaySpecialMoveEffect(x, y, player);
            }
        }

        private bool IsConsecutiveMove(int x, int y)
        {
            if (lastMovePosition == (-1, -1)) return false;
            
            // 检查是否是相邻位置
            int dx = Math.Abs(x - lastMovePosition.Item1);
            int dy = Math.Abs(y - lastMovePosition.Item2);
            return (dx <= 1 && dy <= 1) && (dx + dy > 0);
        }

        private void PlayComboEffect(int x, int y, Player player, int comboCount)
        {
            var screenPos = GetScreenPosition(x, y);
            if (screenPos == null) return;

            // 创建连击数字效果
            TextBlock comboText = new TextBlock
            {
                Text = $"COMBO {comboCount}!",
                FontSize = 20,
                FontWeight = FontWeights.Bold,
                Foreground = player == Player.Black ? Brushes.Blue : Brushes.Yellow,
                Opacity = 1
            };

            Canvas.SetLeft(comboText, screenPos.Value.X - 40);
            Canvas.SetTop(comboText, screenPos.Value.Y - 60);
            effectCanvas.Children.Add(comboText);

            // 动画效果
            var opacityAnimation = new DoubleAnimation
            {
                From = 1,
                To = 0,
                Duration = TimeSpan.FromSeconds(1.5)
            };

            var translateYAnimation = new DoubleAnimation
            {
                From = 0,
                To = -50,
                Duration = TimeSpan.FromSeconds(1.5)
            };

            comboText.BeginAnimation(UIElement.OpacityProperty, opacityAnimation);
            comboText.BeginAnimation(Canvas.TopProperty, translateYAnimation);

            // 动画结束后移除
            DispatcherTimer timer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(1.5)
            };
            timer.Tick += (s, e) =>
            {
                effectCanvas.Children.Remove(comboText);
                timer.Stop();
            };
            timer.Start();
        }

        private void PlayBasicPlacementEffect(int x, int y, Player player)
        {
            // 计算屏幕坐标
            var screenPos = GetScreenPosition(x, y);
            if (screenPos == null) return;

            // 创建光晕效果
            Ellipse glow = new Ellipse
            {
                Width = 60,
                Height = 60,
                Fill = new RadialGradientBrush
                {
                    GradientStops = new GradientStopCollection
                    {
                        new GradientStop(player == Player.Black ? Colors.Blue : Colors.Yellow, 0),
                        new GradientStop(Colors.Transparent, 0.8)
                    }
                },
                Opacity = 0.8
            };

            Canvas.SetLeft(glow, screenPos.Value.X - 30);
            Canvas.SetTop(glow, screenPos.Value.Y - 30);
            effectCanvas.Children.Add(glow);

            // 动画效果
            var opacityAnimation = new DoubleAnimation
            {
                From = 0.8,
                To = 0,
                Duration = TimeSpan.FromSeconds(1.2)
            };

            glow.RenderTransform = new ScaleTransform(1, 1);
            var scaleXAnimation = new DoubleAnimation
            {
                From = 1,
                To = 2,
                Duration = TimeSpan.FromSeconds(1.2)
            };

            var scaleYAnimation = new DoubleAnimation
            {
                From = 1,
                To = 2,
                Duration = TimeSpan.FromSeconds(1.2)
            };

            glow.BeginAnimation(UIElement.OpacityProperty, opacityAnimation);
            ((ScaleTransform)glow.RenderTransform).BeginAnimation(ScaleTransform.ScaleXProperty, scaleXAnimation);
            ((ScaleTransform)glow.RenderTransform).BeginAnimation(ScaleTransform.ScaleYProperty, scaleYAnimation);

            // 动画结束后移除
            DispatcherTimer timer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(1.2)
            };
            timer.Tick += (s, e) =>
            {
                effectCanvas.Children.Remove(glow);
                timer.Stop();
            };
            timer.Start();
        }

        private void PlaySpecialMoveEffect(int x, int y, Player player)
        {
            // 计算屏幕坐标
            var screenPos = GetScreenPosition(x, y);
            if (screenPos == null) return;

            // 创建特殊招式效果（类似《棋魂》中的闪电效果）
            for (int i = 0; i < 8; i++)
            {
                Line lightning = new Line
                {
                    X1 = screenPos.Value.X,
                    Y1 = screenPos.Value.Y,
                    X2 = screenPos.Value.X + (new Random().Next(-40, 40)),
                    Y2 = screenPos.Value.Y + (new Random().Next(-40, 40)),
                    Stroke = player == Player.Black ? Brushes.Blue : Brushes.Yellow,
                    StrokeThickness = 2,
                    Opacity = 0.8
                };

                Canvas.SetLeft(lightning, 0);
                Canvas.SetTop(lightning, 0);
                effectCanvas.Children.Add(lightning);

                // 动画效果
                var opacityAnimation = new DoubleAnimation
                {
                    From = 0.8,
                    To = 0,
                    Duration = TimeSpan.FromSeconds(0.8)
                };

                lightning.RenderTransform = new ScaleTransform(1, 1);
                var scaleXAnimation = new DoubleAnimation
                {
                    From = 1,
                    To = 1.5,
                    Duration = TimeSpan.FromSeconds(0.8)
                };

                var scaleYAnimation = new DoubleAnimation
                {
                    From = 1,
                    To = 1.5,
                    Duration = TimeSpan.FromSeconds(0.8)
                };

                lightning.BeginAnimation(UIElement.OpacityProperty, opacityAnimation);
                ((ScaleTransform)lightning.RenderTransform).BeginAnimation(ScaleTransform.ScaleXProperty, scaleXAnimation);
                ((ScaleTransform)lightning.RenderTransform).BeginAnimation(ScaleTransform.ScaleYProperty, scaleYAnimation);

                // 动画结束后移除
                DispatcherTimer timer = new DispatcherTimer
                {
                    Interval = TimeSpan.FromSeconds(0.8)
                };
                timer.Tick += (s, e) =>
                {
                    effectCanvas.Children.Remove(lightning);
                    timer.Stop();
                };
                timer.Start();
            }

            // 创建中心闪光效果
            Ellipse flash = new Ellipse
            {
                Width = 20,
                Height = 20,
                Fill = Brushes.White,
                Opacity = 1
            };

            Canvas.SetLeft(flash, screenPos.Value.X - 10);
            Canvas.SetTop(flash, screenPos.Value.Y - 10);
            effectCanvas.Children.Add(flash);

            // 动画效果
            var flashOpacityAnimation = new DoubleAnimation
            {
                From = 1,
                To = 0,
                Duration = TimeSpan.FromSeconds(0.5)
            };

            flash.RenderTransform = new ScaleTransform(1, 1);
            var flashScaleXAnimation = new DoubleAnimation
            {
                From = 1,
                To = 3,
                Duration = TimeSpan.FromSeconds(0.5)
            };

            var flashScaleYAnimation = new DoubleAnimation
            {
                From = 1,
                To = 3,
                Duration = TimeSpan.FromSeconds(0.5)
            };

            flash.BeginAnimation(UIElement.OpacityProperty, flashOpacityAnimation);
            ((ScaleTransform)flash.RenderTransform).BeginAnimation(ScaleTransform.ScaleXProperty, flashScaleXAnimation);
            ((ScaleTransform)flash.RenderTransform).BeginAnimation(ScaleTransform.ScaleYProperty, flashScaleYAnimation);

            // 动画结束后移除
            DispatcherTimer flashTimer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(0.5)
            };
            flashTimer.Tick += (s, e) =>
            {
                effectCanvas.Children.Remove(flash);
                flashTimer.Stop();
            };
            flashTimer.Start();
        }

        public void PlayCaptureEffect(List<(int, int)> capturedStones)
        {
            foreach (var (x, y) in capturedStones)
            {
                var screenPos = GetScreenPosition(x, y);
                if (screenPos == null) continue;

                // 创建提子效果
                Ellipse captureEffect = new Ellipse
                {
                    Width = 40,
                    Height = 40,
                    Fill = new RadialGradientBrush
                    {
                        GradientStops = new GradientStopCollection
                        {
                            new GradientStop(Colors.Red, 0),
                            new GradientStop(Colors.Transparent, 0.8)
                        }
                    },
                    Opacity = 0.8
                };

                Canvas.SetLeft(captureEffect, screenPos.Value.X - 20);
                Canvas.SetTop(captureEffect, screenPos.Value.Y - 20);
                effectCanvas.Children.Add(captureEffect);

                // 动画效果
                var opacityAnimation = new DoubleAnimation
                {
                    From = 0.8,
                    To = 0,
                    Duration = TimeSpan.FromSeconds(1)
                };

                captureEffect.RenderTransform = new ScaleTransform(1, 1);
                var scaleXAnimation = new DoubleAnimation
                {
                    From = 1,
                    To = 1.5,
                    Duration = TimeSpan.FromSeconds(1)
                };

                var scaleYAnimation = new DoubleAnimation
                {
                    From = 1,
                    To = 1.5,
                    Duration = TimeSpan.FromSeconds(1)
                };

                captureEffect.BeginAnimation(UIElement.OpacityProperty, opacityAnimation);
                ((ScaleTransform)captureEffect.RenderTransform).BeginAnimation(ScaleTransform.ScaleXProperty, scaleXAnimation);
                ((ScaleTransform)captureEffect.RenderTransform).BeginAnimation(ScaleTransform.ScaleYProperty, scaleYAnimation);

                // 动画结束后移除
                DispatcherTimer timer = new DispatcherTimer
                {
                    Interval = TimeSpan.FromSeconds(1)
                };
                timer.Tick += (s, e) =>
                {
                    effectCanvas.Children.Remove(captureEffect);
                    timer.Stop();
                };
                timer.Start();
            }
        }

        public void PlayGameStartEffect()
        {
            // 游戏开始特效
            for (int i = 0; i < 10; i++)
            {
                int x = new Random().Next(0, 19);
                int y = new Random().Next(0, 19);
                var screenPos = GetScreenPosition(x, y);
                if (screenPos == null) continue;

                Ellipse startEffect = new Ellipse
                {
                    Width = 30,
                    Height = 30,
                    Fill = new RadialGradientBrush
                    {
                        GradientStops = new GradientStopCollection
                        {
                            new GradientStop(Colors.Green, 0),
                            new GradientStop(Colors.Transparent, 0.8)
                        }
                    },
                    Opacity = 0.6
                };

                Canvas.SetLeft(startEffect, screenPos.Value.X - 15);
                Canvas.SetTop(startEffect, screenPos.Value.Y - 15);
                effectCanvas.Children.Add(startEffect);

                // 动画效果
                var opacityAnimation = new DoubleAnimation
                {
                    From = 0.6,
                    To = 0,
                    Duration = TimeSpan.FromSeconds(1.5)
                };

                startEffect.RenderTransform = new ScaleTransform(1, 1);
                var scaleXAnimation = new DoubleAnimation
                {
                    From = 1,
                    To = 2,
                    Duration = TimeSpan.FromSeconds(1.5)
                };

                var scaleYAnimation = new DoubleAnimation
                {
                    From = 1,
                    To = 2,
                    Duration = TimeSpan.FromSeconds(1.5)
                };

                startEffect.BeginAnimation(UIElement.OpacityProperty, opacityAnimation);
                ((ScaleTransform)startEffect.RenderTransform).BeginAnimation(ScaleTransform.ScaleXProperty, scaleXAnimation);
                ((ScaleTransform)startEffect.RenderTransform).BeginAnimation(ScaleTransform.ScaleYProperty, scaleYAnimation);

                // 动画结束后移除
                DispatcherTimer timer = new DispatcherTimer
                {
                    Interval = TimeSpan.FromSeconds(1.5)
                };
                timer.Tick += (s, e) =>
                {
                    effectCanvas.Children.Remove(startEffect);
                    timer.Stop();
                };
                timer.Start();
            }
        }

        public void PlayGameEndEffect(Player winner)
        {
            // 游戏结束特效
            for (int i = 0; i < 20; i++)
            {
                int x = new Random().Next(0, 19);
                int y = new Random().Next(0, 19);
                var screenPos = GetScreenPosition(x, y);
                if (screenPos == null) continue;

                Ellipse endEffect = new Ellipse
                {
                    Width = 40,
                    Height = 40,
                    Fill = new RadialGradientBrush
                    {
                        GradientStops = new GradientStopCollection
                        {
                            new GradientStop(winner == Player.Black ? Colors.Blue : Colors.Yellow, 0),
                            new GradientStop(Colors.Transparent, 0.8)
                        }
                    },
                    Opacity = 0.8
                };

                Canvas.SetLeft(endEffect, screenPos.Value.X - 20);
                Canvas.SetTop(endEffect, screenPos.Value.Y - 20);
                effectCanvas.Children.Add(endEffect);

                // 动画效果
                var opacityAnimation = new DoubleAnimation
                {
                    From = 0.8,
                    To = 0,
                    Duration = TimeSpan.FromSeconds(2)
                };

                endEffect.RenderTransform = new ScaleTransform(1, 1);
                var scaleXAnimation = new DoubleAnimation
                {
                    From = 1,
                    To = 3,
                    Duration = TimeSpan.FromSeconds(2)
                };

                var scaleYAnimation = new DoubleAnimation
                {
                    From = 1,
                    To = 3,
                    Duration = TimeSpan.FromSeconds(2)
                };

                endEffect.BeginAnimation(UIElement.OpacityProperty, opacityAnimation);
                ((ScaleTransform)endEffect.RenderTransform).BeginAnimation(ScaleTransform.ScaleXProperty, scaleXAnimation);
                ((ScaleTransform)endEffect.RenderTransform).BeginAnimation(ScaleTransform.ScaleYProperty, scaleYAnimation);

                // 动画结束后移除
                DispatcherTimer timer = new DispatcherTimer
                {
                    Interval = TimeSpan.FromSeconds(2)
                };
                timer.Tick += (s, e) =>
                {
                    effectCanvas.Children.Remove(endEffect);
                    timer.Stop();
                };
                timer.Start();
            }

            // 添加胜利文字特效
            PlayVictoryTextEffect(winner);
        }

        private void PlayVictoryTextEffect(Player winner)
        {
            // 计算棋盘中心位置
            var centerPos = GetScreenPosition(9, 9);
            if (centerPos == null) return;

            // 创建胜利文字
            TextBlock victoryText = new TextBlock
            {
                Text = $"{(winner == Player.Black ? "黑棋" : "白棋")} 胜利！",
                FontSize = 30,
                FontWeight = FontWeights.Bold,
                Foreground = winner == Player.Black ? Brushes.Blue : Brushes.Yellow,
                Opacity = 0
            };

            Canvas.SetLeft(victoryText, centerPos.Value.X - 80);
            Canvas.SetTop(victoryText, centerPos.Value.Y - 50);
            effectCanvas.Children.Add(victoryText);

            // 动画效果
            var opacityAnimation = new DoubleAnimation
            {
                From = 0,
                To = 1,
                Duration = TimeSpan.FromSeconds(1)
            };

            var scaleAnimation = new DoubleAnimation
            {
                From = 0.5,
                To = 1.2,
                Duration = TimeSpan.FromSeconds(1)
            };

            victoryText.RenderTransform = new ScaleTransform(1, 1);
            victoryText.BeginAnimation(UIElement.OpacityProperty, opacityAnimation);
            ((ScaleTransform)victoryText.RenderTransform).BeginAnimation(ScaleTransform.ScaleXProperty, scaleAnimation);
            ((ScaleTransform)victoryText.RenderTransform).BeginAnimation(ScaleTransform.ScaleYProperty, scaleAnimation);

            // 动画结束后移除
            DispatcherTimer timer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(3)
            };
            timer.Tick += (s, e) =>
            {
                effectCanvas.Children.Remove(victoryText);
                timer.Stop();
            };
            timer.Start();
        }

        public void PlayHoverEffect(int x, int y, Player player)
        {
            if (effectCanvas == null) return;

            var screenPos = GetScreenPosition(x, y);
            if (screenPos == null) return;

            // 创建悬停效果
            Ellipse hoverEffect = new Ellipse
            {
                Width = 40,
                Height = 40,
                Fill = new RadialGradientBrush
                {
                    GradientStops = new GradientStopCollection
                    {
                        new GradientStop(player == Player.Black ? Colors.Blue : Colors.Yellow, 0.3),
                        new GradientStop(Colors.Transparent, 0.8)
                    }
                },
                Opacity = 0.5
            };

            Canvas.SetLeft(hoverEffect, screenPos.Value.X - 20);
            Canvas.SetTop(hoverEffect, screenPos.Value.Y - 20);
            effectCanvas.Children.Add(hoverEffect);

            // 动画效果
            var opacityAnimation = new DoubleAnimation
            {
                From = 0.5,
                To = 0.2,
                Duration = TimeSpan.FromSeconds(0.5)
            };

            hoverEffect.BeginAnimation(UIElement.OpacityProperty, opacityAnimation);

            // 5秒后移除
            DispatcherTimer timer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(5)
            };
            timer.Tick += (s, e) =>
            {
                effectCanvas.Children.Remove(hoverEffect);
                timer.Stop();
            };
            timer.Start();
        }

        public void ClearHoverEffects()
        {
            if (effectCanvas == null) return;

            // 移除所有悬停效果
            var hoverEffects = effectCanvas.Children.OfType<Ellipse>().Where(e => e.Opacity < 0.3).ToList();
            foreach (var effect in hoverEffects)
            {
                effectCanvas.Children.Remove(effect);
            }
        }

        private Point? GetScreenPosition(int x, int y)
        {
            // 计算屏幕坐标
            // 与GoBoardControl中的计算方式一致
            const int BOARD_SIZE = 19;
            const int MARGIN = 20;
            
            double boardSize = Math.Min(boardControl.ActualWidth, boardControl.ActualHeight) - 2 * MARGIN;
            double cellSize = boardSize / (BOARD_SIZE - 1);
            
            // 计算实际屏幕坐标，与GoBoardControl中的绘制逻辑一致
            double screenX = MARGIN + x * cellSize;
            double screenY = MARGIN + y * cellSize;
            
            return new Point(screenX, screenY);
        }

        private bool IsSpecialMove(int x, int y)
        {
            // 简单判断是否为特殊招式（例如星位、天元等关键位置）
            int[] keyPoints = { 3, 9, 15 };
            return keyPoints.Any(p => p == x) && keyPoints.Any(p => p == y);
        }
    }
}