using System;
using System.Media;
using System.IO;

namespace MasterQ.Core
{
    public class AudioSystem
    {
        private SoundPlayer bgmPlayer;
        private SoundPlayer moveSoundPlayer;
        private SoundPlayer captureSoundPlayer;
        private SoundPlayer gameStartSoundPlayer;
        private SoundPlayer gameEndSoundPlayer;
        private SoundPlayer buttonClickSoundPlayer;
        private int volume;

        public AudioSystem()
        {
            volume = 50; // 默认音量
            InitializeAudio();
        }

        private void InitializeAudio()
        {
            // 初始化音效播放器
            // 由于没有实际的音频文件，这里创建简单的音效
            // 实际应用中，应该使用真实的8-bit风格音频文件
            
            // 创建临时音频文件
            CreateTemporaryAudioFiles();

            // 初始化播放器
            try
            {
                bgmPlayer = new SoundPlayer();
                moveSoundPlayer = new SoundPlayer();
                captureSoundPlayer = new SoundPlayer();
                gameStartSoundPlayer = new SoundPlayer();
                gameEndSoundPlayer = new SoundPlayer();
                buttonClickSoundPlayer = new SoundPlayer();

                // 加载音效
                moveSoundPlayer.SoundLocation = Path.Combine(Path.GetTempPath(), "move.wav");
                captureSoundPlayer.SoundLocation = Path.Combine(Path.GetTempPath(), "capture.wav");
                gameStartSoundPlayer.SoundLocation = Path.Combine(Path.GetTempPath(), "game_start.wav");
                gameEndSoundPlayer.SoundLocation = Path.Combine(Path.GetTempPath(), "game_end.wav");
                buttonClickSoundPlayer.SoundLocation = Path.Combine(Path.GetTempPath(), "button_click.wav");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"音频系统初始化失败: {ex.Message}");
            }
        }

        private void CreateTemporaryAudioFiles()
        {
            // 创建简单的8-bit风格音效文件
            // 实际应用中，应该使用真实的音频文件
            try
            {
                // 落子音效
                CreateSimpleWavFile(Path.Combine(Path.GetTempPath(), "move.wav"), 440, 100);
                
                // 吃子音效
                CreateSimpleWavFile(Path.Combine(Path.GetTempPath(), "capture.wav"), 880, 150);
                
                // 游戏开始音效
                CreateSimpleWavFile(Path.Combine(Path.GetTempPath(), "game_start.wav"), 660, 200);
                
                // 游戏结束音效
                CreateSimpleWavFile(Path.Combine(Path.GetTempPath(), "game_end.wav"), 220, 300);
                
                // 按钮点击音效
                CreateSimpleWavFile(Path.Combine(Path.GetTempPath(), "button_click.wav"), 330, 50);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"创建临时音频文件失败: {ex.Message}");
            }
        }

        private void CreateSimpleWavFile(string filePath, int frequency, int duration)
        {
            // 创建一个简单的WAV文件
            // 实际应用中，应该使用真实的8-bit风格音频文件
            try
            {
                using (FileStream fs = new FileStream(filePath, FileMode.Create))
                {
                    // 写入WAV文件头
                    byte[] header = new byte[44];
                    // RIFF标识
                    header[0] = (byte)'R';
                    header[1] = (byte)'I';
                    header[2] = (byte)'F';
                    header[3] = (byte)'F';
                    // 文件长度
                    int fileLength = 44 + duration * 2;
                    BitConverter.GetBytes(fileLength).CopyTo(header, 4);
                    // WAVE标识
                    header[8] = (byte)'W';
                    header[9] = (byte)'A';
                    header[10] = (byte)'V';
                    header[11] = (byte)'E';
                    // fmt标识
                    header[12] = (byte)'f';
                    header[13] = (byte)'m';
                    header[14] = (byte)'t';
                    header[15] = (byte)' ';
                    // 格式长度
                    BitConverter.GetBytes(16).CopyTo(header, 16);
                    // 格式类型
                    BitConverter.GetBytes((short)1).CopyTo(header, 20);
                    // 声道数
                    BitConverter.GetBytes((short)1).CopyTo(header, 22);
                    // 采样率
                    BitConverter.GetBytes(44100).CopyTo(header, 24);
                    // 字节率
                    BitConverter.GetBytes(44100 * 2).CopyTo(header, 28);
                    // 块对齐
                    BitConverter.GetBytes((short)2).CopyTo(header, 32);
                    // 位深度
                    BitConverter.GetBytes((short)16).CopyTo(header, 34);
                    // data标识
                    header[36] = (byte)'d';
                    header[37] = (byte)'a';
                    header[38] = (byte)'t';
                    header[39] = (byte)'a';
                    // 数据长度
                    BitConverter.GetBytes(duration * 2).CopyTo(header, 40);
                    
                    fs.Write(header, 0, header.Length);
                    
                    // 写入音频数据
                    for (int i = 0; i < duration; i++)
                    {
                        // 生成正弦波
                        double t = (double)i / 44100;
                        short sample = (short)(Math.Sin(2 * Math.PI * frequency * t) * 32767 * (volume / 100.0));
                        byte[] sampleBytes = BitConverter.GetBytes(sample);
                        fs.Write(sampleBytes, 0, sampleBytes.Length);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"创建WAV文件失败: {ex.Message}");
            }
        }

        public void PlayMoveSound()
        {
            try
            {
                moveSoundPlayer.Play();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"播放落子音效失败: {ex.Message}");
            }
        }

        public void PlayCaptureSound()
        {
            try
            {
                captureSoundPlayer.Play();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"播放吃子音效失败: {ex.Message}");
            }
        }

        public void PlayGameStartSound()
        {
            try
            {
                gameStartSoundPlayer.Play();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"播放游戏开始音效失败: {ex.Message}");
            }
        }

        public void PlayGameEndSound()
        {
            try
            {
                gameEndSoundPlayer.Play();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"播放游戏结束音效失败: {ex.Message}");
            }
        }

        public void PlayButtonClickSound()
        {
            try
            {
                buttonClickSoundPlayer.Play();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"播放按钮点击音效失败: {ex.Message}");
            }
        }

        public void SetVolume(int volume)
        {
            this.volume = Math.Max(0, Math.Min(100, volume));
            // 重新创建音频文件以应用新音量
            CreateTemporaryAudioFiles();
        }

        public int GetVolume()
        {
            return volume;
        }

        public void Dispose()
        {
            bgmPlayer?.Dispose();
            moveSoundPlayer?.Dispose();
            captureSoundPlayer?.Dispose();
            gameStartSoundPlayer?.Dispose();
            gameEndSoundPlayer?.Dispose();
            buttonClickSoundPlayer?.Dispose();
        }
    }
}