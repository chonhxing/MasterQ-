using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;
using System.Windows.Shapes;
using System.Windows.Threading;
using MasterQ.Core;

namespace MasterQ.UI
{
    public partial class GoBoardControl : UserControl
    {
        private const int GO_BOARD_SIZE = 19;
        private const int GOMOKU_BOARD_SIZE = 15;
        private const int MARGIN = 20;
        private double cellSize;
        private GoRules goRules;
        private GomokuRules gomokuRules;
        private int boardSize;
        private Dictionary<(int, int), Ellipse> stones;
        private Point lastMousePosition;
        private bool isDragging;

        public event EventHandler<(int, int)> MoveMade;

        public GoBoardControl()
        {
            InitializeComponent();
            stones = new Dictionary<(int, int), Ellipse>();
            boardSize = GO_BOARD_SIZE; // 默认围棋棋盘大小
            Loaded += GoBoardControl_Loaded;
        }

        public void SetGoRules(GoRules rules)
        {
            goRules = rules;
            gomokuRules = null;
            boardSize = GO_BOARD_SIZE;
            UpdateBoard();
        }

        public void SetGomokuRules(GomokuRules rules)
        {
            gomokuRules = rules;
            goRules = null;
            boardSize = GOMOKU_BOARD_SIZE;
            UpdateBoard();
        }

        private void GoBoardControl_Loaded(object sender, RoutedEventArgs e)
        {
            DrawBoard();
        }

        private void DrawBoard()
        {
            boardCanvas.Children.Clear();
            double boardSize = Math.Min(boardCanvas.ActualWidth, boardCanvas.ActualHeight) - 2 * MARGIN;
            cellSize = boardSize / (this.boardSize - 1);

            // 绘制网格线
            for (int i = 0; i < this.boardSize; i++)
            {
                // 水平线
                Line horizontalLine = new Line
                {
                    X1 = MARGIN,
                    Y1 = MARGIN + i * cellSize,
                    X2 = MARGIN + (this.boardSize - 1) * cellSize,
                    Y2 = MARGIN + i * cellSize,
                    Stroke = Brushes.Brown,
                    StrokeThickness = 1
                };
                boardCanvas.Children.Add(horizontalLine);

                // 垂直线
                Line verticalLine = new Line
                {
                    X1 = MARGIN + i * cellSize,
                    Y1 = MARGIN,
                    X2 = MARGIN + i * cellSize,
                    Y2 = MARGIN + (this.boardSize - 1) * cellSize,
                    Stroke = Brushes.Brown,
                    StrokeThickness = 1
                };
                boardCanvas.Children.Add(verticalLine);
            }

            // 绘制星位
            int[] starPoints;
            if (this.boardSize == GO_BOARD_SIZE)
            {
                starPoints = new int[] { 3, 9, 15 };
            }
            else // 五子棋棋盘
            {
                starPoints = new int[] { 3, 7, 11 };
            }
            foreach (int x in starPoints)
            {
                foreach (int y in starPoints)
                {
                    Ellipse star = new Ellipse
                    {
                        Width = 8,
                        Height = 8,
                        Fill = Brushes.Brown,
                        Stroke = Brushes.Brown,
                        StrokeThickness = 1
                    };
                    Canvas.SetLeft(star, MARGIN + x * cellSize - 4);
                    Canvas.SetTop(star, MARGIN + y * cellSize - 4);
                    boardCanvas.Children.Add(star);
                }
            }
        }

        public void UpdateBoard()
        {
            if (goRules == null && gomokuRules == null) return;

            stoneCanvas.Children.Clear();
            stones.Clear();

            if (goRules != null)
            {
                var board = goRules.GetBoard();
                for (int x = 0; x < GO_BOARD_SIZE; x++)
                {
                    for (int y = 0; y < GO_BOARD_SIZE; y++)
                    {
                        if (board[x, y] != Player.None)
                        {
                            DrawStone(x, y, board[x, y], false);
                        }
                    }
                }
            }
            else if (gomokuRules != null)
            {
                var board = gomokuRules.GetBoard();
                for (int x = 0; x < GOMOKU_BOARD_SIZE; x++)
                {
                    for (int y = 0; y < GOMOKU_BOARD_SIZE; y++)
                    {
                        if (board[x, y] != Player.None)
                        {
                            DrawStone(x, y, board[x, y], false);
                        }
                    }
                }
            }
        }

        private void DrawStone(int x, int y, Player player, bool animate)
        {
            Ellipse stone = new Ellipse
            {
                Width = cellSize * 0.8,
                Height = cellSize * 0.8,
                Fill = player == Player.Black ? Brushes.Black : Brushes.White,
                Stroke = player == Player.Black ? Brushes.Gray : Brushes.LightGray,
                StrokeThickness = 1
            };

            // 添加2.5D效果
            if (player == Player.Black)
            {
                var gradient = new RadialGradientBrush
                {
                    GradientStops = new GradientStopCollection
                    {
                        new GradientStop(Colors.Gray, 0),
                        new GradientStop(Colors.Black, 0.7)
                    }
                };
                stone.Fill = gradient;
            }
            else
            {
                var gradient = new RadialGradientBrush
                {
                    GradientStops = new GradientStopCollection
                    {
                        new GradientStop(Colors.White, 0),
                        new GradientStop(Colors.LightGray, 0.7)
                    }
                };
                stone.Fill = gradient;
            }

            // 添加阴影效果
            stone.Effect = new DropShadowEffect
            {
                BlurRadius = 5,
                ShadowDepth = 3,
                Color = Colors.Black,
                Opacity = 0.5
            };

            double left = MARGIN + x * cellSize - stone.Width / 2;
            double top = MARGIN + y * cellSize - stone.Height / 2;

            if (animate)
            {
                // 落子动画
                stone.Opacity = 0;
                stone.RenderTransform = new ScaleTransform(0.5, 0.5);

                Canvas.SetLeft(stone, left);
                Canvas.SetTop(stone, top);
                stoneCanvas.Children.Add(stone);

                // 动画效果
                var opacityAnimation = new DoubleAnimation
                {
                    From = 0,
                    To = 1,
                    Duration = TimeSpan.FromSeconds(0.3)
                };

                var scaleXAnimation = new DoubleAnimation
                {
                    From = 0.5,
                    To = 1,
                    Duration = TimeSpan.FromSeconds(0.3)
                };

                var scaleYAnimation = new DoubleAnimation
                {
                    From = 0.5,
                    To = 1,
                    Duration = TimeSpan.FromSeconds(0.3)
                };

                stone.BeginAnimation(UIElement.OpacityProperty, opacityAnimation);
                ((ScaleTransform)stone.RenderTransform).BeginAnimation(ScaleTransform.ScaleXProperty, scaleXAnimation);
                ((ScaleTransform)stone.RenderTransform).BeginAnimation(ScaleTransform.ScaleYProperty, scaleYAnimation);

                // 播放落子音效（这里可以添加音效逻辑）
            }
            else
            {
                Canvas.SetLeft(stone, left);
                Canvas.SetTop(stone, top);
                stoneCanvas.Children.Add(stone);
            }

            stones[(x, y)] = stone;

            // 显示落子光晕特效
            if (animate)
            {
                ShowPlacementEffect(x, y);
            }
        }

        private void ShowPlacementEffect(int x, int y)
        {
            Ellipse effect = new Ellipse
            {
                Width = cellSize * 1.5,
                Height = cellSize * 1.5,
                Fill = new RadialGradientBrush
                {
                    GradientStops = new GradientStopCollection
                    {
                        new GradientStop(Colors.Yellow, 0),
                        new GradientStop(Colors.Transparent, 0.8)
                    }
                },
                Opacity = 0.8
            };

            double left = MARGIN + x * cellSize - effect.Width / 2;
            double top = MARGIN + y * cellSize - effect.Height / 2;

            Canvas.SetLeft(effect, left);
            Canvas.SetTop(effect, top);
            effectCanvas.Children.Add(effect);

            // 动画效果
            var opacityAnimation = new DoubleAnimation
            {
                From = 0.8,
                To = 0,
                Duration = TimeSpan.FromSeconds(0.8)
            };

            effect.RenderTransform = new ScaleTransform(1, 1);
            var scaleXAnimation = new DoubleAnimation
            {
                From = 1,
                To = 1.5,
                Duration = TimeSpan.FromSeconds(0.8)
            };

            var scaleYAnimation = new DoubleAnimation
            {
                From = 1,
                To = 1.5,
                Duration = TimeSpan.FromSeconds(0.8)
            };

            effect.BeginAnimation(UIElement.OpacityProperty, opacityAnimation);
            ((ScaleTransform)effect.RenderTransform).BeginAnimation(ScaleTransform.ScaleXProperty, scaleXAnimation);
            ((ScaleTransform)effect.RenderTransform).BeginAnimation(ScaleTransform.ScaleYProperty, scaleYAnimation);

            // 动画结束后移除特效
            DispatcherTimer timer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(0.8)
            };
            timer.Tick += (s, e) =>
            {
                effectCanvas.Children.Remove(effect);
                timer.Stop();
            };
            timer.Start();
        }

        private (int, int) GetBoardCoordinates(Point mousePoint)
        {
            int x = (int)Math.Round((mousePoint.X - MARGIN) / cellSize);
            int y = (int)Math.Round((mousePoint.Y - MARGIN) / cellSize);

            // 边界检查
            x = Math.Max(0, Math.Min(x, boardSize - 1));
            y = Math.Max(0, Math.Min(y, boardSize - 1));

            return (x, y);
        }

        private void GoBoardControl_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (goRules == null && gomokuRules == null) return;

            Point mousePoint = e.GetPosition(stoneCanvas);
            var (x, y) = GetBoardCoordinates(mousePoint);

            // 只触发事件，由GameManager处理落子逻辑
            MoveMade?.Invoke(this, (x, y));
        }

        public void HighlightPossibleMoves(List<(int, int)> moves)
        {
            indicatorCanvas.Children.Clear();

            foreach (var (x, y) in moves)
            {
                Ellipse indicator = new Ellipse
                {
                    Width = cellSize * 0.4,
                    Height = cellSize * 0.4,
                    Fill = Brushes.Green,
                    Opacity = 0.3
                };

                double left = MARGIN + x * cellSize - indicator.Width / 2;
                double top = MARGIN + y * cellSize - indicator.Height / 2;

                Canvas.SetLeft(indicator, left);
                Canvas.SetTop(indicator, top);
                indicatorCanvas.Children.Add(indicator);
            }
        }

        public void ClearHighlights()
        {
            indicatorCanvas.Children.Clear();
        }

        protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo)
        {
            base.OnRenderSizeChanged(sizeInfo);
            DrawBoard();
            UpdateBoard();
        }
    }
}